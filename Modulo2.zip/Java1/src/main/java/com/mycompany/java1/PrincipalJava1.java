/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.java1;

/**
 *
 * @author DELL GAMING
 */
public class PrincipalJava1 {
    
     /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
       // TODO code application logic here
    }
}
